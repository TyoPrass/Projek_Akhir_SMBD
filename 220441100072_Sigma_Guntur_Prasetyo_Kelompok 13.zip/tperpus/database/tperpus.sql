-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 11 Jun 2024 pada 15.48
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tperpus`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE `buku` (
  `id_buku` int(11) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `pengarang` varchar(200) NOT NULL,
  `penerbit` varchar(200) NOT NULL,
  `tahun_rilis` varchar(200) NOT NULL,
  `kategori` varchar(200) NOT NULL,
  `jumlah_buku` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`id_buku`, `judul`, `pengarang`, `penerbit`, `tahun_rilis`, `kategori`, `jumlah_buku`) VALUES
(1, 'PP', 'PP', 'PP', '2020-05-05', 'Aksi', 10),
(2, 'Chernobyl12', 'asdf', 'adsf', '2024-06-21', 'adf', 14);

-- --------------------------------------------------------

--
-- Struktur dari tabel `iniadmin`
--

CREATE TABLE `iniadmin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `pass` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `iniadmin`
--

INSERT INTO `iniadmin` (`id_admin`, `username`, `email`, `pass`) VALUES
(2, 'admin', 'admin@admin.com', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `peminjaman`
--

CREATE TABLE `peminjaman` (
  `id_peminjaman` int(10) NOT NULL,
  `id_pengguna` int(10) NOT NULL,
  `id_buku` int(10) NOT NULL,
  `username` varchar(200) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  `denda` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `peminjaman`
--

INSERT INTO `peminjaman` (`id_peminjaman`, `id_pengguna`, `id_buku`, `username`, `judul`, `tgl_pinjam`, `tgl_kembali`, `denda`) VALUES
(10, 1, 2, 'SS', 'Chernobyl12', '2024-06-02', '2024-06-06', 10000),
(11, 1, 1, 'SS', 'PP', '2024-06-10', '2024-06-17', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengembalian`
--

CREATE TABLE `pengembalian` (
  `id_pengembalian` int(10) NOT NULL,
  `id_buku` int(10) NOT NULL,
  `id_pengguna` int(10) NOT NULL,
  `username` varchar(200) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `tgl_kembali` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pengembalian`
--

INSERT INTO `pengembalian` (`id_pengembalian`, `id_buku`, `id_pengguna`, `username`, `judul`, `tgl_pinjam`, `tgl_kembali`) VALUES
(29, 1, 9, 'Sigma', 'PP', '2024-06-11', '2024-06-11'),
(30, 1, 9, 'Sigma', 'PP', '2024-06-11', '2024-06-11'),
(31, 1, 9, 'Sigma', 'PP', '2024-06-11', '2024-06-11'),
(32, 1, 9, 'Sigma', 'PP', '2024-06-11', '2024-06-11'),
(33, 2, 9, 'Sigma', 'Chernobyl12', '2024-06-11', '2024-06-11'),
(34, 1, 9, 'Sigma', 'PP', '2024-06-11', '2024-06-11'),
(35, 2, 9, 'Sigma', 'Chernobyl12', '2024-06-11', '2024-06-11'),
(36, 1, 9, 'Sigma', 'PP', '2024-06-11', '2024-06-11'),
(37, 2, 9, 'Sigma', 'Chernobyl12', '2024-06-11', '2024-06-11'),
(38, 1, 9, 'Sigma', 'PP', '2024-06-11', '2024-06-11'),
(39, 1, 9, 'Sigma', 'PP', '2024-06-11', '2024-06-11'),
(40, 2, 9, 'Sigma', 'Chernobyl12', '2024-06-11', '2024-06-11');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `pass` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `username`, `email`, `pass`) VALUES
(1, 'SS', 'AA@gmail.com', '123'),
(2, 'Tymo', 'prasetyosigma2@gmail.com', '123'),
(3, 'sigma09', 'sigma.top123@gmail.com', '123'),
(4, 'jj', 'jj@jj', '123'),
(5, 'Dibaca', 'DIbaca@Gmail.com', 'Baca'),
(6, 'Dibaca1', 'DIbaca1@Gmail.com', 'Baca'),
(7, 'Dibaca12', 'DIbaca1@12Gmail.com', 'Baca'),
(8, 'Dibaca123', 'DIbaca1@123Gmail.com', 'Baca'),
(9, 'Sigma', '123@a.com', '123'),
(10, 'Tono', '123@ab.com', '123');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`);

--
-- Indeks untuk tabel `iniadmin`
--
ALTER TABLE `iniadmin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indeks untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`id_peminjaman`),
  ADD KEY `id_pengguna` (`id_pengguna`),
  ADD KEY `id_buku` (`id_buku`);

--
-- Indeks untuk tabel `pengembalian`
--
ALTER TABLE `pengembalian`
  ADD PRIMARY KEY (`id_pengembalian`),
  ADD KEY `id_pengguna` (`id_pengguna`),
  ADD KEY `id_buku` (`id_buku`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `buku`
--
ALTER TABLE `buku`
  MODIFY `id_buku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `iniadmin`
--
ALTER TABLE `iniadmin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `id_peminjaman` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT untuk tabel `pengembalian`
--
ALTER TABLE `pengembalian`
  MODIFY `id_pengembalian` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`),
  ADD CONSTRAINT `peminjaman_ibfk_2` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id_buku`);

--
-- Ketidakleluasaan untuk tabel `pengembalian`
--
ALTER TABLE `pengembalian`
  ADD CONSTRAINT `pengembalian_ibfk_3` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`),
  ADD CONSTRAINT `pengembalian_ibfk_4` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id_buku`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
