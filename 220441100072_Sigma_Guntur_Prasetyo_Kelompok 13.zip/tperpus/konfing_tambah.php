<?php
// Start the session
session_start();

// Include database connection
require_once "koneksi.php";

// Ensure user is logged in
if (!isset($_SESSION['status']) || $_SESSION['status'] !== "login successful") {
    header("Location: login.php");
    exit;
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form input
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun_rilis = $_POST['tahun_rilis'];
    $kategori = $_POST['kategori'];
    $jumlah_buku = intval($_POST['jumlah_buku']);

    // Check if the book title already exists
    $check_stmt = $koneksi->prepare("SELECT COUNT(*) FROM buku WHERE judul = ?");
    if ($check_stmt === false) {
        die('Prepare() failed: ' . htmlspecialchars($koneksi->error));
    }
    $check_stmt->bind_param("s", $judul);
    $check_stmt->execute();
    $check_stmt->bind_result($count);
    $check_stmt->fetch();
    $check_stmt->close();

    if ($count > 0) {
        $_SESSION['message'] = "Error: Judul Buku Sudah Tersedia";
        $koneksi->close();
        echo "<script>
            alert('Error: Judul Buku Sudah Tersedia');
            document.location.href='tambah.php';
            </script>";
        exit;
    } else {
        // Prepare and bind for insert
        $stmt = $koneksi->prepare("CALL InsertBuku(?, ?, ?, ?, ?, ?)");
        if ($stmt === false) {
            die('Prepare() failed: ' . htmlspecialchars($koneksi->error));
        }

        // Use "sssssi" for binding parameters (five strings and one integer)
        $stmt->bind_param("sssssi", $judul, $pengarang, $penerbit, $tahun_rilis, $kategori, $jumlah_buku);

        // Execute the statement
        if ($stmt->execute()) {
            $_SESSION['message'] = "New record created successfully";
            $stmt->close();
            $koneksi->close();
            echo "<script>
                alert('Tambah Buku Berhasil');
                document.location.href='buku.php';
                </script>";
            exit();
        } else {
            $_SESSION['message'] = "Error: " . $stmt->error;
            $stmt->close();
            $koneksi->close();
            echo "<script>
                alert('Error: " . htmlspecialchars($stmt->error) . "');
                document.location.href='tambah.php';
                </script>";
            exit();
        }
    }
}
